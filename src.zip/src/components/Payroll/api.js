// Constants
const ATTENDANCE_STATUS_COLORS = {
  present: 'bg-[#4CAF50]',
  absent: 'bg-[#F44336]',
  late: 'bg-[#FF9800]',
  leave: 'bg-[#9C27B0]',
  holiday: 'bg-[#FFC107]',
  weekOff: 'bg-gray-400',
  remote: 'bg-[#2196F3]',
  empty: 'bg-gray-200'
};

const DAY_LABELS = ["S", "M", "T", "W", "T", "F", "S"];

// Mock API delay
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Dummy API to fetch employees
export const fetchEmployees = async () => {
  // Simulate API call delay
  await delay(500);
  
  return [
    {
      id: 1,
      name: 'John Doe',
      department: 'Sales',
      empId: 'EMP-001',
      attendance: ['present', 'present', 'absent', 'holiday', 'present', 'present', 'weekOff', 'leave', 'present', 'present', 'present', 'present', 'present', 'late', 'present', 'present', 'present', 'present', 'holiday', 'present', 'present', 'remote', 'present', 'present']
    },
    {
      id: 2,
      name: 'Mary Wilson',
      department: 'Engineering',
      empId: 'EMP-002',
      attendance: ['present', 'leave', 'late', 'present', 'present', 'remote', 'present', 'present', 'present', 'weekOff', 'present', 'present', 'present', 'present', 'present', 'present', 'absent', 'present', 'present', 'present', 'present', 'present', 'present', 'present']
    },
    {
      id: 3,
      name: 'David Brown',
      department: 'Finance',
      empId: 'EMP-003',
      attendance: ['present', 'present', 'present', 'remote', 'present', 'present', 'present', 'present', 'holiday', 'leave', 'present', 'present', 'weekOff', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present']
    },
    {
      id: 4,
      name: 'Emily Johnson',
      department: 'HR',
      empId: 'EMP-004',
      attendance: ['present', 'present', 'present', 'present', 'late', 'holiday', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'weekOff', 'present', 'present', 'present', 'present', 'present', 'present']
    },
    {
      id: 5,
      name: 'Tom Anderson',
      department: 'Operations',
      empId: 'EMP-005',
      attendance: ['present', 'present', 'present', 'holiday', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present']
    },
    {
      id: 6,
      name: 'Tom Anderson',
      department: 'HR',
      empId: 'EMP-006',
      attendance: ['present', 'present', 'present', 'holiday', 'present', 'present', 'present', 'present', 'leave', 'present', 'present', 'present', 'weekOff', 'present', 'present', 'late', 'present', 'present', 'present', 'present', 'present', 'present', 'present', 'present']
    },
  ];
};

// API to update employee attendance
export const updateEmployeeAttendance = async (employeeId, attendanceData) => {
  await delay(300);
  console.log(`Updated attendance for employee ${employeeId}:`, attendanceData);
  return { success: true };
};

// Export constants for use in components
export { ATTENDANCE_STATUS_COLORS, DAY_LABELS };
